modpack para mis amigos, if you not mi amogis, idk ya here mateh


## 1.0.0
- Initial Release
- Remember that Ratatatat74 didn't netorare spy x family
- Ne regarder jamais CouilleMan alors qu'il morbe (ALEPH)
- CrazyMan n'a pas de langue