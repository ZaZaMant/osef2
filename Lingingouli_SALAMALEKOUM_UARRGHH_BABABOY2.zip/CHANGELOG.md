## 1.0.0
- Initial Release
- Bingchilling realm
- Added Lingingouligouli